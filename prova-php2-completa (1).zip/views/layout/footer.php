</div>
<footer>
    &copy; <?php echo date('Y'); ?> Empresa XYZ
</footer>
</body>
</html>