<form action="" method="post">
    Usuario: <input type="text" name="usuario">
    Senha: <input type="password" name="senha">
    <input type="submit" value="Login">
</form>